default_app_config = 'apps.games.apps.GamesConfig'
