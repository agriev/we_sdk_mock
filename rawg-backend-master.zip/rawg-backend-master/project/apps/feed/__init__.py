default_app_config = 'apps.feed.apps.FeedConfig'
