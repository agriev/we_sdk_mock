default_app_config = 'apps.charts.apps.ChartsConfig'
