from django.apps import AppConfig


class ChartsConfig(AppConfig):
    name = 'apps.charts'
    verbose_name = 'Charts'
