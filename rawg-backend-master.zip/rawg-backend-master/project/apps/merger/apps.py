from django.apps import AppConfig


class MergerConfig(AppConfig):
    name = 'apps.merger'
    verbose_name = 'Merger'
