default_app_config = 'apps.oauth2.apps.OAuth2Config'
