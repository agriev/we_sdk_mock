from django.apps import AppConfig


class OAuth2Config(AppConfig):
    name = 'apps.oauth2'
    verbose_name = 'OAuth2'
