default_app_config = 'apps.images.apps.ImagesConfig'
