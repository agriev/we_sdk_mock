from django.apps import AppConfig


class RecommendationsConfig(AppConfig):
    name = 'apps.recommendations'
    verbose_name = 'Recommendations'
