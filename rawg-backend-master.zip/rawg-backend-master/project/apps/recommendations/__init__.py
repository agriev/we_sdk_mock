default_app_config = 'apps.recommendations.apps.RecommendationsConfig'
