default_app_config = 'apps.credits.apps.CreditsConfig'
