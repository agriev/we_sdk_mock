default_app_config = 'apps.mocks.apps.MocksConfig'
