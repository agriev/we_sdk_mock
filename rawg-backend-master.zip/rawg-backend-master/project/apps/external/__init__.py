default_app_config = 'apps.external.apps.ExternalConfig'
