from django.apps import AppConfig


class ExternalConfig(AppConfig):
    name = 'apps.external'
    verbose_name = 'External'
