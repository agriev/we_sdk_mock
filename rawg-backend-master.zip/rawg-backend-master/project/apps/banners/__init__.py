default_app_config = 'apps.banners.apps.BannersConfig'
