default_app_config = 'apps.mailer.apps.MailerConfig'
