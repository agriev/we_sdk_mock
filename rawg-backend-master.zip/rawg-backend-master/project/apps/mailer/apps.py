from django.apps import AppConfig


class MailerConfig(AppConfig):
    name = 'apps.mailer'
    verbose_name = 'Mailer'
