default_app_config = 'apps.discussions.apps.DiscussionsConfig'
