from api.paginations import PageNumberPagination


class CommentPagination(PageNumberPagination):
    page_size = 20
