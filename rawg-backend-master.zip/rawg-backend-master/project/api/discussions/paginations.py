from api.paginations import PageNumberCountPagination


class DiscussionPagination(PageNumberCountPagination):
    page_size = 10
